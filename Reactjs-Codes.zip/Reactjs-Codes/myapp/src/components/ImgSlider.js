import React from 'react'

export const ImgSlider = () => {
  return (
    <div>ImgSlider</div>
  )
}
