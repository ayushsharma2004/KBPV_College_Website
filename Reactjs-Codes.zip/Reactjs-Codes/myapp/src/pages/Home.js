// import React from 'react'
import React, { useRef, useState } from "react";
// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
import "../Styles/home.css";
import Navbar from "../components/Navbar";
import board from "../Images/schl-board1.png";
import slider1 from "../Images/home-img-slider1.jpg";
import slider2 from "../Images/home-img-slider2.jpg";
import slider3 from "../Images/home-img-slider3.jpg";
import slider4 from "../Images/home-img-slider4.jpg";
import slider5 from "../Images/home-img-slider5.jpg";
import slider6 from "../Images/home-img-slider6.jpg";
import slider7 from "../Images/home-img-slider7.jpg";
import slider8 from "../Images/home-img-slider8.jpg";
import slider9 from "../Images/home-img-slider9.jpg";

const Home = () => {
  return (
    <>
    <div className="sub-nav-container">
      
    </div>

      <div className="nav-container">
      <p>Do you want to Translate ?</p>
      <div className="dropdown">
        <button
          className="btn btn-secondary dropdown-toggle bg-white text-black"
          type="button"
          data-bs-toggle="dropdown"
          aria-expanded="false"
        >
          Translate
        </button>
        <ul className="dropdown-menu">
          <li>
            <a className="dropdown-item" href="#">
              Marathi
            </a>
          </li>
          <li>
            <a className="dropdown-item" href="#">
              Hindi
            </a>
          </li>
          <li>
            <a className="dropdown-item" href="#">
              English
            </a>
          </li>
        </ul>
      </div>
        <Navbar />
      </div>

      <div id="slider-container">
        {/* <img src={board} alt="Image Slider" /> */}
        <div id="swiper-container">
          <Swiper
            slidesPerView={1}
            spaceBetween={30}
            loop={true}
            autoplay={{
              delay: 2500,
              disableOnInteraction: false,
            }}
            pagination={{
              clickable: true,
            }}
            navigation={true}
            modules={[Autoplay, Pagination, Navigation]}
            className="mySwiper"
          >
            <SwiperSlide>
              <img src={slider1} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider2} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider3} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider4} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider5} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider6} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider7} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider8} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            <SwiperSlide>
              <img src={slider9} alt="Image Slider" className="imgs" />
            </SwiperSlide>
            
          </Swiper>
        </div>
      </div>
    </>
  );
};

export default Home;
